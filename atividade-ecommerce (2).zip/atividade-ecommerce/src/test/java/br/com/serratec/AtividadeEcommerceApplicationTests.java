package br.com.serratec;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AtividadeEcommerceApplicationTests {

	@Test
	void contextLoads() {
	}

}
